import dis

print(dis.opmap)