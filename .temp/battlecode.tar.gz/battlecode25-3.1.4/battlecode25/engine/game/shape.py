from enum import Enum

class Shape(Enum): # marker shapes
    RESOURCE=0
    DEFENSE_TOWER=1
    MONEY_TOWER=2
    PAINT_TOWER=3